CKEDITOR.plugins.setLang("pbckcode", "ru",
  {
    title: 'PBCKCODE',
    addCode: 'Добавить код',
    editCode: 'Редактировать код',
    editor: 'Редактор',
    settings: 'Настройки',
    mode: 'Режим',
    tabSize: 'Ширина табуляции',
    theme: 'Тема',
    softTab: 'Включить мягкую табуляцию',
    emmet: 'Включить Emmet'
  });
