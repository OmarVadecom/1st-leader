CKEDITOR.plugins.setLang("pbckcode", "tr",
  {
    title: 'PBCKCODE',
    addCode: 'Kod ekle',
    editCode: 'Kodu düzenle',
    editor: 'Editör',
    settings: 'Ayarlar',
    mode: 'Mod',
    tabSize: 'Sekme boyutu',
    theme: 'Tema',
    softTab: 'Yumuşak sekmeleri aktif et',
    emmet: 'Emmet\'i aktif et'
  });
