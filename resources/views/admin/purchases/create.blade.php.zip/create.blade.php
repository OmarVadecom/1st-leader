@extends($pLayout. 'master')
@section('content')
  <section id="justified-top-border">
  	<div class="row match-height">
  		<div class="col-xs-12">
  			<div class="card">
  				<div class="card-header">
					  <h4 class="card-title">انشاء فاتوره شراء</h4>
					  <h4 class="card-title-ohda" style="text-align:left;">العهده الخاصه بك: <span class="user_ohda">{{$totalohda}}</span></h4>
				  </div>
          {!! Form::open([
              'url' => route('purchase.store'),
              'method', 'POST'
              ]) !!}
  				<div class="card-body">
  					<div class="card-block">
  						@include('admin.purchase.form')
  					</div>
  				</div>
		  {!! Form::close() !!}
  			</div>
  		</div>
  	</div>
  </section>
@endsection

@section('script')

@endsection
