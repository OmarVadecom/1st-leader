@extends($pLayout. 'master')

@section('content')

<!-- File export table -->
<section id="file-export">
    <div class="row">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">
                        المشتريات
                    </h4>
                    <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                        	<li class="tag tag-info">{{ trans('admin.select') }} <input type="checkbox" class="checkedAll" name="dels"></li>
                            <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                           <button class="btn btn-success" id="print">طباعه</button>
                           
                            {!! getCreateBtn(route('purchase.create'), 'sliders.create') !!}
                        </ul>
                    </div>
                </div>
                <div class="card-body collapse in">
                    <div class="card-block card-dashboard table-responsive">
                        <table class="table table-striped table-bordered " id="data">
                         <thead>
                            <tr>
                                <th>#</th>
                                <th>رقم الفاتوره</th>
                                <th>بتاريخ</th>
                                <th>المخزن</th>
                                <th>السائق</th>               
                                <th>المورد</th>
                                {{-- <th>اجمالي المشتريات</th> --}}
                                <th class="headpr">{{ trans('admin.action') }}</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                        <tfoot>
                            <tr>
                                <th>#</th>
                                <th>رقم الفاتوره</th>
                                <th>بتاريخ</th>
                                <th>المخزن</th>
                                <th>السائق</th>               
                                <th>المورد</th>
                                {{-- <th>اجمالي المشتريات</th> --}}
                                <th class="headpr">{{ trans('admin.action') }}</th>
                            </tr>
                        </tfoot>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

@endsection


@section('script')
<script type="text/javascript">
	$(document).ready(function() {
    $('#data').DataTable( {
        "processing": true,
            "language": {
            "sUrl": lang
        },
        "ordering": true,
        "pagingType": "full_numbers",
            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            iDisplayLength: 25,
        "fixedHeader": true,
        "responsive": true,
        "ajax": "{{ route('admin.purchase.ajax') }}",
        "columns": [
           {data: 'select', name: ''},
           {data: 'title', name: 'title'},
           {data: 'date', name: 'date'},
           {data: 'store', name: 'store'},
           {data: 'driver', name: 'driver'},
           {data: 'supplier', name: 'supplier'},
        //    {data: 'total', name: 'total'},
           {data: 'action', name: ''}
        ],

    });
    
          $("#print").click(function(){
             window.print();
           })  
    
});
</script>
<style>
    @media print {
.headpr,.pagination,.dataTables_info,#data_filter,.dataTables_length{
    display:none !important;;
}
td:last-child {
  display :none;
}
.pagination{
    display :none;
}

body.vertical-layout.vertical-menu.menu-expanded .content, body.vertical-layout.vertical-menu.menu-expanded .footer{
    margin-right: 0px !important;
}
.table-responsive {
    overflow-x: inherit !important;
}

.heading-elements .list-inline{
    display:none !important;
}
    }
    .table td {
    padding: 0.75rem 1rem;
}
</style>
@endsection