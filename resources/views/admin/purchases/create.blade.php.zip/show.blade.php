@extends($pLayout. 'masterinv')
@section('content')
<div class="text-right">
    <button id="printInvoice" class="btn btn-info" style="margin: 5px;"><i class="fa fa-print"></i> طباعه</button>
<a id="back" href="{{url('/')}}/purchase" class="btn btn-danger" ><i class="fa fa-print"></i> رجوع</a>

</div>
    <div class="table-container text-center p-5" id="print">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="pb-4">بيان شـراء</h4>
                    <table class="table table-head table-bordered">
                        <thead>
                          <tr>
                            <th scope="col">رقم</th>
                            <td scope="col">{{$purchase->id}}</td>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row">تاريخ اليوم</th>
                          <td>{{date('d-m-Y',strtotime($purchase->created_at))}}</td>
                          </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-12">
                    <table class="table table-bordered">
                        <thead>
                          <tr>
                            <th scope="col">اسم المورد</th>
                            <td scope="col" colspan="3">{{(isset($purchase->supplier->name)) ? $purchase->supplier->name : ''}}</td>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row">اسم السائق</th>
                            @if(isset($purchase->driver))
                            <td colspan="3">{{$purchase->driver->name}}</td>
                            @endif
                          </tr>
                          <tr>
                            <th scope="row">كود السائق</th>
                            @if(isset($purchase->driver))
                            <td style="width: 250px;">{{$purchase->driver->code}}</td>
                            @else
                              <td style="width: 250px;"></td>
                            @endif
                            <td style="font-weight: bold;">اسم امين المخزن</td>
                            <td style="width: 250px;">{{$purchase->user->name}}</td>
                          </tr>
                        </tbody>
                      </table>
                </div>
                <div class="col-md-12">
                    <table class="table table-bordered">
                        <thead>
                          <tr>
                            <th scope="col">كود المنتج</th>
                            <th scope="col">نوع المنتج</th>
                            <th scope="col">الكمية</th>
                          </tr>
                        </thead>
                        <tbody>
                            @foreach($products as $key=>$product)
                            @php
                            $pproduct=\App\Models\Product::find($product);
                            @endphp
                          <tr>
                            <th scope="row">{{$pproduct->code}}</th>
                            <td>{{$pproduct->title}}</td>
                            <td>{{$quantities[$key]}}</td>
                          </tr>
                          @endforeach

                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
@endsection

