@if($expensestatus==null)
<div class="col-md-4">
  <hr>
  <h4><i class="fa fa-bookmark"></i> {{ trans('admin.shared_values') }}</h4>

  <div class="col-md-12">
    <div class="form-group">
      <label for="title">المورد</label>
      <select name="supplier_id" class="form-control" required>
        <option value="">اختر المورد</option>
        @foreach ($suppliers as $supplier)
        <option value="{{$supplier->id}}"
          {{(isset($purchase) && $purchase->supplier_id==$supplier->id) ? 'selected' : ''}}>{{$supplier->name}}</option>
        @endforeach
      </select>
    </div>
  </div>


  @if(Auth::user()->type == 1)
  <div class="col-md-12">
    <div class="form-group">
      <label for="title">المخزن</label>
      <select name="store_id" class="form-control" required>
        <option value="">اختر المخزن</option>
        @foreach ($stores as $store)
        <option value="{{$store->id}}" {{(isset($purchase) && $purchase->store_id==$store->id) ? 'selected' : ''}}>
          {{$store->name}}</option>
        @endforeach
      </select>
    </div>
  </div>
  @else
  <input type="hidden" name="store_id" value="{{Auth::user()->store_id}}">
  @endif


  <div class="col-md-12">
    <div class="form-group">
      <label for="title">السائق</label>
      <select name="driver_id" class="form-control selectproducted" required>
        <option value="">اختر السائق</option>
        @foreach ($drivers as $driver)
        <option value="{{$driver->id}}" {{(isset($purchase) && $purchase->driver_id==$driver->id) ? 'selected' : ''}}>
          {{$driver->name}} | {{$driver->phonenumber}}</option>
        @endforeach
      </select>
    </div>
  </div>

  <input type="hidden" name="prstatus" id="prstatus" value="0">

</div>








  <div class="col-md-8" style=" padding: 0px; ">
    <div class="col-md-12 table-responsive" style=" padding: 0px; ">
    @if(session()->get('error'))
    <div class="error">{!! session()->get('error') !!}</div>
    @endif
    <table class="table table-striped" style="text-align:center">
      <thead>
        <tr>
          <th width='70%'>المنتج</th>
          <th width='25%'>الكميه</th>
          @if(!isset($purchase))
          <th width='5%'>*</th>
          @endif
        </tr>
      </thead>
      <tbody class="productsadd">
        <div class="form-group ">
          @if(isset($purchase))
          @foreach($allproducts as $key=>$singleproduct)
          <tr>
            <td>
              <select name="product[]" data-number="0" class="form-control selectproduct selectproducted" required>
                <option value="">اختر المنتج</option>
                @foreach($products as $product)
                <option data-price="{{$product->price}}" value="{{ $product->id }}"
                  {{($product->id == $singleproduct) ? 'selected' : ''}}>{{ $product->store->name }} | {{ $product->code }} -
                  {{ $product->title }}
                </option>
                @endforeach
              </select>
            </td>


            <td>
              <input type="number" value="{{$quantities[$key]}}" placeholder="الكميه" min="1"
                class="form-control productquantity" name="quantity[]" required>


              <input type="hidden" name="old_quantity[]" value="{{$quantities[$key]}}">
            </td>


          </tr>
          @endforeach
          @else
          <tr>
            <td>
              <select name="product[]" data-number="0" class="form-control selectproduct selectproducted" required>
                <option value="">اختر المنتج</option>
                @foreach($products as $product)
                <option style="direction:rtl;" data-price="{{$product->price}}" value="{{ $product->id }}">{{ $product->store->name }} | {{ $product->code }} -
                  {{ $product->title }} </option>
                @endforeach
              </select>

            </td>

            <td>
              <input type="number"  placeholder="الكميه" min="1" class="form-control productquantity"
                name="quantity[]" required>
            </td>

            <td><i class="fa fa-close close-icon"></i></td>

          </tr>
          @endif

        </div>
      </tbody>
    </table>
    @if(!isset($purchase))
    <button id="add-product" style="float:left; margin-top:10px;" class="btn btn-success">اضف منتج أخر</button>
    @endif
  </div>

</div>


<div class="col-md-12">
  <hr>
  <div class="clear">
    <!--<button type="submit" class="btn btn-primary">-->
    <!--  <i class="icon-check2"></i> {{ trans('admin.save') }}-->
    <!--</button>-->
    <button type="submit" id="print" class="btn btn-primary">
      <i class="icon-check2"></i> حفظ وطباعه
    </button>
    <a href="{{ route('purchase.index') }}" class="btn btn-danger">
      <i class="fa fa-times"></i> {{ trans('admin.cancel') }}
    </a>
  </div>
</div>

<style>
  i.fa.fa-close.close-icon {
    font-size: 15px;
    margin-top: 7px;
    color: #d40000;
    padding: 5px;
    background: #f1e0e0;
    cursor: pointer;
  }

  span.total-price {
    display: block;
    margin-top: 5px;
    color: #2a8e75;
  }

  .card-title-ohda {
    text-align: left;
    font-size: 12px;
    margin-top: -15px;
    color: #967adc;
    font-weight: bold;
  }

  .error {
    padding: 15px;
    background: #fbe6e6;
    color: red;
  }

  .select2-container {
    margin-top: 5px !important;
    width: 100% !important;
    direction: rtl;
    text-align: right;
  }
  .table td {
    padding: 0.75rem 0.5rem;
}
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js" defer></script>
<script>
  $(document).ready(function(){
  $(document).on("click",".close-icon",function() {
    $(this).parent().parent().remove();
  })

$("#print").click(function(){
  $("#prstatus").val(1);
})


  i=0;

  $("#add-product").click(function(){
      i++;
  $(".productsadd").append('<tr><td><select name="product[]" data-number="'+i+'" class="form-control selectproduct selectproducted" required> <option value="">اختر المنتج</option> @foreach($products as $product) <option data-price="{{$product->price}}" value="{{ $product->id }}">{{ $product->store->name }} | {{ $product->code }} - {{ $product->title }}</option> @endforeach </select> </td><td> <input type="number"  placeholder="الكميه" min="1" class="form-control productquantity" name="quantity[]" Required> </td> <td><i class="fa fa-close close-icon"></i></td> </tr>');
  $(".selectproducted").select2();
  // $('.selectproduct').select2();
  return false;
  })

  $(".productquantity").keyup(function(){


  })

  // $('.selectproduct').select2();


  $(document).on('change','.selectproducted',function(){
  num=$(this).data('number');
  price=$(this).find(':selected').data('price');
  unit=$(this).find(':selected').data('unit');

  // $('.price'+num).val(price);
  })


$(".selectproducted").select2();
  })
</script>

@else
<div class="col-md-12">
  <p class="payment_status" style="text-align:center;padding: 15px; background: antiquewhite;"> تم اضافه تكلفه لهذه
    الفاتوره </p>
</div>
@endif